from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase
from src.db import get_mongo_session
from src.api.auth_utils import require_admin
from bson import ObjectId

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/users")
async def get_all_users(
    admin = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_mongo_session)
):
    users = await db["users"].find().to_list(length=100)

    return [
        {
            "id": str(u["_id"]),
            "username": u.get("username"),
            "email": u.get("email"),
            "is_admin": u.get("is_admin", False)
        }
        for u in users
    ]

@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    admin = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_mongo_session)
):
    try:
        object_id = ObjectId(user_id)
    except:
        raise HTTPException(status_code=400, detail="ID invalid")

    result = await db["users"].delete_one({"_id": object_id})

    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Utilizatorul nu a fost găsit")

    return {"message": f"Utilizatorul cu ID {user_id} a fost șters"}

